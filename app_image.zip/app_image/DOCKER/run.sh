#!/bin/bash
set -m
umask 022
# common function
setup()
{
        NODEIP=`ip -4 -f inet addr show | grep -oP '(?<=inet\s)\d+(\.\d+){3}' | grep -v 127.0.0.1`
        NAME1=`echo $NODEIP | awk -F"." '{print$3"-"$4}'`
        NAME="myapp-${NAME1}"
	sudo setfacl -R -m u:myapp:rwx /opt
	sudo setfacl -m u:myapp:rwx /etc/hosts
        sudo chown myapp.myapp /data/myapp -R

        mkdir /data/myapp/run -p
        mkdir /data/myapp/logs/${NODEIP}/{app-logs,logs} -p
        ln -s /data/myapp/logs/${NODEIP}  /data/myapp/run/logs
}

# qa/dev run function
setupqa()
{
	echo "starting $1 environment"
	echo "setting jvm options"
        if [ "$JVM_OPTS" ]
        then
        	export JAVA_OPTS="$JVM_OPTS"
        else
                export JAVA_OPTS="-Xms1024M -Xmx1024M"
        fi

	P1=`tr -cd '[:alnum:]' < /dev/urandom | fold -w4 | head -n1`
	echo "myapp:myapp#${P1}" | sudo chpasswd

        echo "starting $APPLICATION..."
        if [ "$START_SCRIPT" ]
        then
                exec /bin/sh /data/myapp/launcher.sh &
        else
                exec /bin/sh /data/myapp/start-app.sh & 
        fi

	echo "starting sshd for $1 server"
	echo "login password is == myapp#${P1}"
	sudo /usr/sbin/sshd -D
}


setupprod()
{
	echo "starting PROD environment"
	echo "setting hostfile"
	cat /opt/hostfile/hosts > /etc/hosts

	echo "setting jvm option"
	if [ "$JVM_OPTS" ]
	then
		export JAVA_OPTS="$JVM_OPTS -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/data/myapp/run/tomcat/logs/ -XX:OnOutOfMemoryError="/opt/hostfile/OutOfMemory.sh""
	else
	        export JAVA_OPTS="-Xms1024M -Xmx1024M"
	fi

	echo "starting $APPLICATION..."
        if [ "$START_SCRIPT" ]
        then
		exec /bin/sh /data/myapp/launcher.sh
        else
		exec /bin/sh /data/myapp/start-app.sh
        fi
}

# initilize script here
#- setup
setup

case "$1" in
QA|RFS|DEV|TEST)
        setupqa
        ;;
PROD)
        setupprod
        ;;
*)
        echo "Invalid Environment, check with Linux Team"
	exec "$@"
        ;;
esac
