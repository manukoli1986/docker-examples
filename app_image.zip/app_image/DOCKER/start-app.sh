#1/bin/bash
set -e
echo "hello test image"
/data/myapp/java/jdk8/bin/java -jar *.jar 
