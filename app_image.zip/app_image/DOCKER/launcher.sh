#!/bin/sh
set -e
java -jar *.jar
