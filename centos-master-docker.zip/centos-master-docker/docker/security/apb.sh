#export TMOUT=900
export HISTTIMEFORMAT='%d/%m/%y %T'
export LANG="en_US.UTF-8" 
export LANGUAGE="en_US:en" 
export LC_ALL="en_US.UTF-8" 
export TERM=xterm 
